// Captura informações para transição de Aulas
var totalAulas = 0;
var totalAtividades = 0;

var nav = document.querySelector('body header nav');
nav.appendChild(sumario('.teoria .slide', 'nav-teoria', 't-'));
nav.appendChild(sumario('.atividades .slide', 'nav-atividades', 'a-'));


var hash = location.hash;

if (hash.split('-')[0] != '#a') {
    document.querySelector('#nav-atividades').classList.add('fechado');
} else if (hash.split('-')[0] == '#a') {
    document.querySelector('#nav-teoria').classList.add('fechado');
}
function sumario(query, id, seletor) {
    var secao = document.createElement("ol");
    secao.id = id;
    var slideList = document.querySelectorAll(query);
    for (var i = 0; i < slideList.length; i++) {
        var li = document.createElement("li");
        var a = document.createElement("a");

        var slide = slideList[i];
        var titulo = slide.querySelector("h1");
        slide.id = seletor + i;

        a.id = "a_#" + slide.id;
        a.onclick = function () {
            carregaaula(this.id);
        }
        a.textContent = titulo.textContent;
        li.appendChild(a);
        secao.appendChild(li);
    }
    if (seletor == 'a-') {
        totalAtividades = i - 1;
    } else {
        totalAulas = i - 1;
    }

    return secao;
}
function tocarAudio(event, audioId) {
    var audioEl = document.getElementById(audioId);
    if (!audioEl.paused) {
        audioEl.pause();
        audioEl.currentTime = 0;
    } else
        audioEl.play();
    event.preventDefault();
}
/* Prepara Próximo e Anterior
 Pega Numero da aula Atual */

var aulaAtual = 0;
var idatual = '#t-0';
var tipoAtual = '#t';
if (location.hash.split('-')[0] == '#a' || location.hash.split('-')[0] == '#t') {
    var aulaAtual = hash.split('-')[1];
    var idatual = location.hash;
    var tipoAtual = hash.split('-')[0];
}

carregaaula("a_" + idatual);

function carregaaula(id) {
    //Limpa anteriores
    $('#nav-atividades').find('li a').each(function () {
        $(this).attr('style', '')
    });
    $('#nav-teoria').find('li a').each(function () {
        $(this).attr('style', '')
    });
    document.getElementById(id).style.color = 'yellow';
    document.getElementById(id).style.background = 'yellow';
    id = id.split('_')[1];
    var tipoAtual = id.split('-')[0];
    var aulaAtual = id.split('-')[1];

    $('.slide').each(function () {
        $(this).hide();
    });
    $(id).show();
//Monta Próximo e Anterior
    var proximoLink = '';
    var anteriorLink = '';


    if (tipoAtual == '#a') {
        document.querySelector('#nav-teoria').classList.add('fechado');
        document.querySelector('#nav-atividades').classList.remove('fechado');
        if (aulaAtual == 0) {
            proximoLink = tipoAtual + '-' + (parseInt(aulaAtual) + 1);
            anteriorLink = '#t-' + totalAulas;
        } else if (aulaAtual < totalAtividades) {
            anteriorLink = tipoAtual + '-' + (parseInt(aulaAtual) - 1);
            proximoLink = tipoAtual + '-' + (parseInt(aulaAtual) + 1);
        } else {
            anteriorLink = tipoAtual + '-' + (parseInt(aulaAtual) - 1);
            proximoLink = '';
        }

    }

    if (tipoAtual == '#t' || tipoAtual == '') {
        document.querySelector('#nav-teoria').classList.remove('fechado');
        document.querySelector('#nav-atividades').classList.add('fechado');
        if (aulaAtual == 0) {
            proximoLink = tipoAtual + '-' + (parseInt(aulaAtual) + 1);
        } else if (aulaAtual < totalAulas) {
            anteriorLink = tipoAtual + '-' + (parseInt(aulaAtual) - 1);
            proximoLink = tipoAtual + '-' + (parseInt(aulaAtual) + 1);
        } else {
            anteriorLink = tipoAtual + '-' + (parseInt(aulaAtual) - 1);
            proximoLink = "#a-0";
        }

    }

    $('#proximo').off('click');
    $('#anterior').off('click');
    if (anteriorLink == '') {
        $('#proximo').attr('onclick', 'carregaaula("a_' + proximoLink + '")');
        $('#proximo').show();

    } else if (proximoLink == '') {
        $('#anterior').attr('onclick', 'carregaaula("a_' + anteriorLink + '")');
        $('#anterior').show();

    } else {
        $('#proximo').attr('onclick', 'carregaaula("a_' + proximoLink + '")');
        $('#anterior').attr('onclick', 'carregaaula("a_' + anteriorLink + '")');
        $('#anterior').show();
        $('#proximo').show();
    }

    return false;
}


//Atividades: Adiciona Validação Certo Errado
$('.multipla-escolha > input').click(function () {
    var valorcorreto = $('#' + this.name + "-sol").val();
    if (this.value == valorcorreto) {
        $("label[for=" + this.id + "]").css('font-size', '40px');
        alert('Valor correto');

    } else {
        alert('Valor incorreto');
    }


});

//Habilita Fullscreen
$(document).ready(function () {
    $(".fullscreen_button").on("click", function ()
    {
        document.fullScreenElement && null !== document.fullScreenElement || !document.mozFullScreen && !document.webkitIsFullScreen ? document.documentElement.requestFullScreen ? document.documentElement.requestFullScreen() : document.documentElement.mozRequestFullScreen ? document.documentElement.mozRequestFullScreen() : document.documentElement.webkitRequestFullScreen && document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT) : document.cancelFullScreen ? document.cancelFullScreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitCancelFullScreen && document.webkitCancelFullScreen()
    });
});

