var nav = document.querySelector('body header nav');
nav.appendChild(sumario('.teoria .slide', 'nav-teoria'));
nav.appendChild(sumario('.atividades .slide', 'nav-atividades'));
var hash = location.hash;
if (hash.split('-')[0] != '#a') {
    document.querySelector('#nav-atividades').classList.add('fechado');
}
else if (hash.split('-')[0] == '#a') {
    document.querySelector('#nav-teoria').classList.add('fechado');
}
function sumario(query, id) {
    var secao = document.createElement("ol");
    secao.id = id;
    var slideList = document.querySelectorAll(query);
    for (var i = 0; i < slideList.length; i++) {
        var li = document.createElement("li");
        var a = document.createElement("a");
        var slide = slideList[i];
        var titulo = slide.querySelector("h1");
        slide.id = "t-" + i;
        a.href = "#" + slide.id;
        a.textContent = titulo.textContent;
        li.appendChild(a);
        secao.appendChild(li);
    }
    return secao;
}
function tocarAudio(event, audioId) {
	
    var audioEl = document.getElementById(audioId);
    if (!audioEl.paused) {
        audioEl.pause();
        audioEl.currentTime = 0;
    }
    else{
        audioEl.play();
		
		
	}
    event.preventDefault(); 
	
	  
	
}
