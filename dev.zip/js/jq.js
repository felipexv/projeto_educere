/*
let main: HTMLElement = document.getElementById("aula");
function redimensionar() {
    let altura = main.offsetHeight;
    let licoes: NodeList = document.querySelectorAll('article');
    for (let i = 0; i < licoes.length; i++) {
        let licao: HTMLElement = licoes[i] as HTMLElement;
        let licaoAltura = licao.offsetHeight;
        let licaoLargura = licao.offsetWidth;
        
    }
}
*/

var main = $('#aula');

$(document).ready(
function(){
redimensionar()
$(window).resize(redimensionar);
}
);

function redimensionar() {
    var alturaMain = $(window).height();
    var larguraMain = $(window).width();
	var licoes = $('.slide');
    licoes.each(function () {
            
        $(this).css({
            height: alturaMain,
			width: larguraMain
        });
    });

	
	
}
//$(window).resize(redim);

//redim();